package com.example.flutter_noite_banco

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
